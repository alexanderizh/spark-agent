# Spark Agent Engine

`@spark/agent` is a deterministic, event-sourced coding agent engine with two first-class entry surfaces today:

- `spark` CLI and terminal UI;
- an embeddable TypeScript SDK.

A versioned App Server protocol for hosts such as SparkWork is planned for M3. Until then,
`spark serve` exits with an explicit unsupported-command message instead of starting a server.

The package is intentionally self-contained. It does not import or depend on any SparkWork workspace package.

## Requirements

- Node.js `>=22.14.0 <23`
- npm 10 or newer

## Development

```bash
npm install
npm run verify
npm run build
node dist/cli/main.js --help
```

## Installing the `spark` command

Three equivalent paths put `spark` on PATH:

- one-line installer from the static release server (the built-in release base below is compiled into the CLI, installers, and scripts — override anytime with `--base <url>` / `-Base <url>` / `SPARK_INSTALL_BASE`):

  ```bash
  # macOS / Linux — latest release
  curl -fsSL https://raw.githubusercontent.com/alexanderizh/spark-agent/spark-cli-releases/install.sh | sh
  ```

  ```powershell
  # Windows PowerShell
  irm https://raw.githubusercontent.com/alexanderizh/spark-agent/spark-cli-releases/install.ps1 | iex
  ```

  The installer enforces the Node engine range, downloads the versioned tarball, verifies its sha256 against the release manifest (`latest.json` or the `.sha256` sidecar for pinned versions), installs it with npm, and — when the npm global bin is not on PATH — falls back to `spark install` for the `~/.spark/bin` launcher. `--tarball <path>` / `SPARK_INSTALL_TARBALL` installs a local file with no download (the hook the SparkWork desktop app uses for its future install button). Build the distributable directory with `node scripts/prepare-release.mjs [out-dir]` (tarball + `.sha256` + `latest.json`); upload it to any static host.

- `npm install -g @spark/agent` — the bin is managed by npm;
- from any install location (cloned repo, unpacked tarball, local folder): `spark install` links a launcher into `~/.spark/bin` (override with `--bin <dir>`). On Unix it is a symlink to the package entry, so in-place package updates flow through automatically; on Windows it writes a `spark.cmd` shim.

`spark install` never depends on the working directory: the package root is located from the running code itself and verified by package name. It refuses to overwrite a foreign file at the launcher path unless `--force` is passed, prints the exact `export PATH=...` (or `fish_add_path`) line when the bin directory is not on PATH, and warns when another `spark` appears earlier on PATH. `spark uninstall` removes only launchers that provably belong to spark.

## Updating spark

```bash
spark update --check          # report only; deterministic exit codes
spark update                  # upgrade to the latest release
spark upgrade                 # alias of update
spark update --target 1.2.3   # pin an exact version (checksum via .sha256 sidecar)
spark update --allow-prerelease
spark update --json           # machine-readable one-line status
```

Exit codes: `0` an update is available or was applied · `1` up to date, remote older, or prerelease gated · `2` usage error · `3` check or upgrade failed · `4` another update is in progress.

Every check downloads a strictly validated `latest.json` (package identity must be `@spark/agent`, strict SemVer version, lowercase hex sha256, deterministic tarball name) over https — loopback http is accepted only for local testing. Redirects that leave the release origin are refused; size caps and timeouts bound every response. Before anything is touched, the downloaded tarball is checksum-verified, its embedded `package.json` identity/version must match the manifest, and its `engines.node` must accept the running Node.

The upgrade itself is transactional: install into a staging prefix inside the npm global tree, verify the staged CLI reports the expected version, then swap the whole staged package directory by rename with the previous installation snapshotted first (dependencies ride inside the package) — any later failure (version probe, `spark doctor`, launcher relink) rolls everything back, so a failed update always leaves the previous spark runnable. A cross-process lock at `~/.spark/update.lock` serializes concurrent updates: a live owner is always honored, a provably dead owner (ESRCH) is retaken immediately, and a lock older than 15 minutes is removed and retaken so a crashed or recycled-pid updater can never wedge updates permanently.

Source precedence for where updates come from: `--base/--target` flags > `SPARK_RELEASE_BASE`/`SPARK_INSTALL_BASE`/`SPARK_INSTALL_VERSION` env > `[update]` in `~/.spark/config.toml` (`base_url`, `version`) > built-in release host. The channel is deliberately steered only by flags/env/global config: a repo-local `.spark/config.toml` may toggle `[update] enabled` for the daily notice but its `base_url`/`version` are ignored by design, so a checked-out project can never hijack the update path.

Interactive TUI sessions print a one-line notice on stderr when a newer release exists. The notice checks at most once per day (cached in `~/.spark/update-check.json`), is skipped entirely for `--json`/`--plain`/piped/CI runs, and is disabled with `SPARK_UPDATE_CHECK=0` or `[update] enabled = false`. An unreachable release host never blocks startup or turns.

## Uninstalling spark

```bash
spark uninstall               # remove the ~/.spark/bin launcher only
spark uninstall --package     # full removal: npm package + proven bin shims + launcher
```

`spark uninstall --package` removes only what provably belongs to spark — the `@spark/agent` package in the npm global tree, its bin shims there, and the `~/.spark/bin` launcher. It never deletes `~/.spark` configuration, sessions, or caches, never follows into foreign packages sharing the tree, and never touches a third-party `spark` found elsewhere on PATH (it is reported instead). Running it twice is safe (`absent`). This intentionally does not uninstall the code this command executes from when installed via `npm link` development setups — remove those with `npm unlink -g @spark/agent`.

## Publishing a release (maintainers)

```bash
node scripts/prepare-release.mjs [out-dir]
```

produces the immutable release set: `spark-agent-<version>.tgz` (npm pack), its `<...>.sha256` sidecar, the three installers, and `latest.json`. Versioned artifacts are immutable — republishing the same version with different bytes is a hard error; bump `package.json` instead.

Publishing is GitHub-native and credential-free: the release workflow commits the directory to the `spark-cli-releases` branch, whose raw URLs (`https://raw.githubusercontent.com/alexanderizh/spark-agent/spark-cli-releases/...`) are exactly what installers, `spark update`, and the public verifier consume. All versions coexist on that branch, so pinned installs of old releases keep working; `latest.json` is the only mutable pointer and is committed last. Raw CDN caching means a just-published version can take up to five minutes to become visible everywhere.

```bash
node scripts/verify-release.mjs [dir] [--base <url>]   # public HTTPS check against any base
```

`scripts/release-contract.mjs` carries the shared schema/base-URL contract for all tools; CI runs prepare → publish-to-branch → verify in the spark-engine publish workflow.

## Recovering from a failed update

If an updater was killed mid-transaction, the next `spark update` restores consistency automatically from its snapshot before proceeding. If automatic restore was impossible (e.g. permissions), the error message names the backup directory to move back manually. `spark doctor` shows the resolved PATH entry's version versus the running one — a stale launcher after manual repair is reported as version drift.

First run without local configuration: `spark` still opens the TUI and shows the model picker — SparkWork routes (live catalog), locally configured models, and a terminal provider-configuration wizard (`c`). The wizard writes a local provider into `~/.spark/config.toml` referencing credentials only by environment-variable name; nothing secret is ever stored. `/model` reopens the picker between turns (a running turn keeps its model). Non-interactive invocations (`--plain`, `--json`, piped prompts) stay fail-fast with actionable guidance. `spark init` remains for scripting; `spark doctor` reports the resolved `spark` on PATH (broken links, version drift, shadowing), stale SparkWork bridge descriptors, and Node engine compliance.

## Interactive session controls

The TUI uses a graphite-and-mint terminal theme with flat, shared selection rows for the model, permission, effort, session, approval, and command pickers. Truecolor/256-color terminals use a solid focus fill; 16-color and mono terminals fall back to inverse video. A persistent divided status line under the input keeps the model, permission mode, reasoning effort, latest model-call performance, working directory, and `/help` visible; the help hint stays right-aligned when space permits.

| Command   | Action                                                    |
| --------- | --------------------------------------------------------- |
| `/model`  | Open the model picker (SparkWork routes + local channels) |
| `/perm`   | Switch permission policy for this session                 |
| `/effort` | Cycle reasoning effort: low → medium → high → max → off   |
| `/status` | Session id, queued turns, event count, current controls   |
| `/clear`  | Start a fresh session                                     |
| `/help`   | Command reference (Tab completes any prefix)              |

Permission switching is persistent: `/perm` opens the three-mode picker `manual` → `auto` → `bypass`, and the selected mode is saved as the CLI default in `~/.spark/config.toml`. The destructive `bypass` entry demands a second Enter to arm, and single-key cycling never reaches it — bypass requires going through the picker or launching with `--permission-mode bypass`. Resumed sessions still keep their recorded mode unless an explicit flag overrides it.

Reasoning effort (`/effort`, or `--effort off|low|medium|high|max` on one-shot runs) maps onto each protocol's native control and the TUI selection is saved as the CLI default in `~/.spark/config.toml`. SparkWork routes provide the authoritative context window and maximum generated-token budget; Spark clamps each request to those limits and then reserves space for the current prompt. Anthropic receives an enabled-thinking budget below `max_tokens`, while OpenAI Responses receives the corresponding `reasoning.effort`. An exhausted context window fails with a structured diagnostic instead of sending a request that cannot produce a response.

Approvals remain fail-closed: every side-effecting tool call renders a card with the exact arguments, policy reason, and risk class, offering allow-once, allow-for-session (when the policy grants that scope), and deny; Esc always denies.

### Images in a prompt

Press `Ctrl+V` to attach the picture on the clipboard; on Windows/WSL terminals `Alt+V` does the
same. The image becomes an atomic `[Image #N]` block in the draft — Backspace deletes it whole,
deleting one renumbers the rest, and a placeholder removed from the text is simply not sent (the
rest of the prompt still goes out). The submitted text keeps `[Image #N]`, so the model can refer
to "the second image". Pasting a path to an existing image file attaches that file instead of
inserting the path text.

```sh
spark -p "分析这张截图" -i shot.png -i arch.jpg   # one-shot runs take images too
```

Supported containers are PNG/JPEG/WEBP/GIF, up to 20 MB per image, 50 MB and 20 images per turn.
Bytes are stored content-addressed (`<dataRoot>/artifacts/<sha256>`), so the ledger records only a
reference and replays reproduce the same picture. The clipboard is read through the platform tool
— JXA/AppKit on macOS (PNG → JPEG → copied file → TIFF converted in process), `wl-paste`/`xclip` on
Linux, and an STA PowerShell script on Windows/WSL — so no native clipboard dependency is bundled.
A model whose channel never declared image input still receives the picture; Spark only shows a
one-time hint, and a real provider rejection surfaces as an ordinary turn failure.

Some terminals send the paste key through their own paste channel, where a picture — which has no
text representation — arrives as an *empty* pasted string; Spark treats that empty paste as a
clipboard-image read, so `Ctrl+V` (or the terminal's own paste key) attaches the picture either
way. While a model picker or an approval prompt owns the keyboard the draft is locked: an image
paste then reports which prompt is holding the input instead of appearing to do nothing.

## Configuration

`spark` reads `~/.spark/config.toml` and then `<cwd>/.spark/config.toml`, merging them with the
project file taking precedence (lists replace instead of appending). Both files stay 0600, and every
edit made through `spark config` is validated against the full schema before an atomic write, so a
rejected edit never leaves a half-written file behind.

```bash
spark config                       # list effective keys with their source layer
spark config get permissions.mode  # print one value (raw in text mode)
spark config set tools.disabled '["task"]' --project
spark config unset permissions.mode
spark config path                  # both file paths and whether they exist
```

Sections beyond the model channels:

```toml
[permissions]
mode = "manual"                    # default permission mode for new sessions
allow = ["read", "glob", "grep"]   # no approval prompt in manual mode
deny = ["bash"]                    # hard deny: enforced in manual, auto, and bypass
ask = ["write", "edit"]            # always require approval

[tools]
disabled = ["task"]                # hidden from the model and denied at execution
# enabled = ["read", "grep"]       # exclusive allowlist instead of disabled

[mcp.servers.filesystem]           # stdio transport
command = "npx"
args = ["-y", "@modelcontextprotocol/server-filesystem", "/tmp"]
env = { LOG_LEVEL = "info" }       # stdio servers also inherit your shell environment

[mcp.servers.remote]               # Streamable HTTP transport
url = "https://example.com/mcp"
headers = { Authorization = "Bearer ${REMOTE_MCP_TOKEN}" }

[platform]
server_url = "https://spark.yiqibyte.com/"    # Spark account server
# web_login_url = "https://www.yiqibyte.com/login"
```

Tool patterns use the same `*` wildcard syntax as permission rules (`mcp__*`, `ba*`). Deny entries are
hard denies rather than ordinary rules: `bypass` skips policy rules but never a configured deny.
`${VAR}` references in MCP `env` and `headers` values resolve from the environment at load time and
fail with an actionable message when the variable is unset, so credentials stay out of the file.

### Managing MCP servers

```bash
spark mcp list                                        # configured servers, transport, layer
spark mcp add filesystem --command npx --arg -y --arg @modelcontextprotocol/server-filesystem --arg /tmp
spark mcp add remote --url https://example.com/mcp --header Authorization='Bearer token'
spark mcp status                                      # start every enabled server, report its tools
spark mcp remove filesystem
```

Configured servers are connected for every CLI and TUI session; their tools appear as
`mcp__<server>__<tool>` and go through the normal permission, budget, and ledger path. A server that
fails to start never blocks the session: `spark` reports the failure on stderr and continues with the
built-in tools. `spark mcp status` is the diagnostic that starts the processes deliberately (15s per
server) and exits non-zero if any server fails.

### Project task list

The standalone CLI includes a small project-local task list at `.spark/todos.json`. It is intended for
durable execution state that the model and a human can share; it is not a replacement for the
SparkWork board or cross-device synchronization.

```bash
spark todo add "Implement the next slice" --priority high --notes "Run the smoke test"
spark todo list --limit 20
spark todo update <todo_id> --status in_progress
spark todo update <todo_id> --status completed
spark todo remove <todo_id>
spark todo clear                 # completed/cancelled only
spark todo clear --all           # explicitly remove every task
```

The model receives `todo_list` (read-only) and `todo_update` (add/update/complete/remove). Writes use
the normal permission policy and are serialized; the JSON file is schema-validated and atomically
replaced, so malformed data or an interrupted write does not silently become a new task state.

### Session execution plans

The standalone CLI also keeps the active session's execution plan as Markdown at
`.spark/plans/<session_id>.md`. Plans are intentionally separate from `.spark/todos.json`: a plan
captures the current turn's steps and decisions, while todos are durable project tasks shared by
future sessions.

```bash
spark plan show [session_id]
spark plan set [session_id] --body "# Plan\n\n1. Inspect\n2. Verify"
spark plan append [session_id] --body "3. Ship"
spark plan clear [session_id]
```

When no session id is given, the CLI uses the most recently updated user session in the current
directory. The model gets a no-approval `plan` read tool and a serialized, permission-controlled
`plan_update` write tool with `set`, `append`, and `clear` operations. Plan content is capped at
256 KiB and written atomically.

### Local skills and progressive disclosure

CLI/TUI sessions discover local `SKILL.md` documents from the user home and the current directory's
ancestor chain. Supported roots are `.spark/skills`, `.claude/skills`, `.codex/skills`, and
`.agents/skills`; a more specific project root overrides a global skill with the same name. Each
document needs YAML frontmatter with non-empty `name` and `description` fields.

```bash
spark skills list
spark skills list react --limit 20
spark skills read <skill_id_or_name>
```

The model receives `skills_list` as a compact name/description catalog and calls `skills_load` only
when it has selected a skill. Loading returns the Markdown body without frontmatter, is read-only,
and never executes scripts from the skill directory. Documents are bounded to 256 KiB by default;
the SDK keeps this tool family opt-in through `skillsEnabled` so existing embeddings do not change
their default tool set.

### Spark account login

`spark login` signs the CLI in to your Spark account with the same browser handshake the desktop app
uses: the CLI generates a `state` and a PKCE verifier, opens the web login page, and polls until the
page binds the state (`--no-browser` prints the URL instead, for headless or SSH sessions). Only
`state` and `sha256(verifier)` reach the browser; the verifier is exchanged exactly once and never
written to disk before the exchange succeeds.

```bash
spark login                 # open the login page and wait for the browser
spark login --no-browser    # print the login url and wait for it to be opened elsewhere
spark whoami                # show the signed-in account (--json for machine output)
spark logout                # delete the stored session
```

The session is stored in `~/.spark/credentials.json` with `0600` permissions and an atomic replace —
tokens are never written to `config.toml`, printed to the terminal, or included in fact events.
Expired access tokens are refreshed automatically (one request at a time) and the rotated session is
persisted. When a refresh is rejected, `spark whoami` deletes the dead session and tells you to log in
again instead of reporting a stale identity.

The account server comes from `[platform] server_url`, overridable with `SPARK_EDUGEN_BASE_URL`; the
web login page comes from `[platform] web_login_url`, then the server's `/client-config`, then a
built-in default, and can be overridden with `SPARK_WEB_LOGIN_URL`.

## Model configuration

Spark reads `~/.spark/config.toml` and then project `.spark/config.toml`. Provider credentials are referenced by environment-variable name and are never stored in the config or session snapshot.

When SparkWork is running, the CLI also discovers its currently enabled Provider/model catalog through an authenticated loopback host bridge. SparkWork remains the credential owner: provider API keys stay in its Keychain/encrypted vault and are never copied into CLI configuration or fact events. Selection precedence is CLI flag / environment / project config, then the SparkWork default route, then global config.

```toml
[agent]
model = "primary"
failover = []
max_retries = 2
retry_initial_delay_ms = 500
retry_max_delay_ms = 60000
retry_jitter_ratio = 0.2

[providers.openai]
protocol = "openai-responses"
base_url = "https://api.openai.com/v1"
api_key_env = "OPENAI_API_KEY"

[models.primary]
provider = "openai"
model = "your-model-id"
# Optional standalone limits when SparkWork is not supplying the route.
context_window = 128000
max_tokens = 64000
```

Anthropic uses `protocol = "anthropic-messages"` and defaults to `ANTHROPIC_API_KEY`. Select another configured model with `spark --model <id>` or `SPARK_MODEL=<id>`.

```bash
spark "inspect this repository and run the relevant tests"
spark --json --model primary "explain the current failure"
spark --output-format stream-json --model primary "stream machine-readable events"
spark --permission-mode manual "design the change without editing files"
spark models
spark doctor
```

For automation, stdout has a strict contract: default text mode writes only the
final answer to stdout and sends diagnostics to stderr. `--json` keeps the
backward-compatible persisted-event JSONL stream. `--output-format json` writes
one final result object, while `--output-format stream-json` writes persisted
events plus live `delta` records as JSONL. A failed or cancelled turn still
produces a result/status record and returns a non-zero process status.

The production CLI/TUI requires a configured real model. `FakeModel`, `VirtualFileSystem`, and `FakeShell` remain exported only as deterministic SDK test seams.

Built-in workspace tools are `read`, `glob`, `grep`, `write`, `edit`, and `bash`; `web_fetch` retrieves bounded readable text from HTTPS pages (localhost HTTP is allowed for development) and always uses the external-tool approval class. CLI/TUI also expose local `skills_list` / `skills_load` for progressive `SKILL.md` disclosure. The `task` tool can delegate focused prompts to isolated child sessions: children are read-only by default, `allowed_tools` is an exact capability allowlist, and each child has independent step/tool-call/time budgets while inheriting the parent turn's permission mode and reasoning effort. Independent read-only task calls from one model step run concurrently, with a shared SDK limit of four active children by default (`maxConcurrentSubagents`, 1–32); mutation-capable children remain serial while they share a workspace. Child ledgers are hidden from normal session listings and `--continue`; the returned child session id can be used for explicit inspection or resume, with its allowlist re-applied. File writes are atomic and require the SHA-256 revision returned by `read` when replacing an existing file.

When Spark is embedded by a host, the host can provide stable system/skill prompt sections, custom environment variables, permission lists, and MCP servers. Spark passes custom environment variables only to its workspace shell and hook children; configured MCP servers receive only their own explicit server environment. MCP `stdio` and Streamable HTTP transports are supported by the Spark engine; legacy SSE and in-process SDK servers are skipped at the boundary. Host team tools use the same Streamable HTTP bridge as other external consumers, so tool calls retain normal permission and event handling.

Permission modes are `manual`, `auto`, and `bypass`. `bypass` requires the explicit `--permission-mode bypass` or `--dangerously-skip-permissions` flag and prints a danger warning. Every policy result is persisted as a `permission.evaluated` fact event.
