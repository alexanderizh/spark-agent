---
name: Sample Skill
description: A fixture skill for testing
version: 1.0.0
---

# Sample Skill
For vitest only.
